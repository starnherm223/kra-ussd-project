<?php
require_once('connection.php');
require_once 'AfricasTalkingGateway.php';
require_once 'config.php';

//receive http post from AT
$sessionId=$_POST['sessionId'];
$serviceCode=$_POST['serviceCode'];
$phoneNumber=$_POST['phoneNumber'];
$text=$_POST['text'];

//=====get the value of the latest interaction as we explode the text
$textArray=explode('*',$text);
$userRespense=trim(end($textArray));

//===========set the level to 0, this to enable grab user session level as it keeps graduating to the next
$level=0;

//=============check the session level of the user================
$sql1="SELECT * FROM session_level WHERE sessionId='".$sessionId."'";
$sqlQuery1=$conn->query($sql1);
if($resultSql1=$sqlQuery1->fetch_assoc()){
    $level=$resultSql1['level'];
}

//checj if user is registered in the db
$sql2="SELECT * FROM register WHERE phoneNumber LIKE '%".$phoneNumber."%'";
$sqlQuery2=$conn->query($sql2);
$userAvailable=$sqlQuery2->fetch_assoc();

if($userAvailable and $userAvailable['name'] !='' and $userAvailable['phone'] !='' and $userAvailable['reg_number'] !=''){
//============serve the menu============;
   switch ($userRespense){
       case "":
           if($level==0){
               if($level==0 || $level==1){
                   $sql3="INSERT INTO session_level(session_id,phoneNumber,level)VALUES ('$sessionId','$phoneNumber',1)";
                   $conn->query($sql3);

//        display response
                   $response="CON Welcome to TESTING USSD REGISTRATION, ".$userAvailable['name']." Choose a service\n";
                   $response .="1. View details\n";
                   $response .="2. Register\n";
                   $response .="3. Please call me\n";
//        print the response on the page
                   header("Content-type: text/plain");
                   echo $response;

               }

           }
           break;

       case "0":
           if($level==0){
               if($level==0 || $level==1){
                   $sql3="INSERT INTO session_level(session_id,phoneNumber,level)VALUES ('$sessionId','$phoneNumber',1)";
                   $conn->query($sql3);

//        display response
                   $response="CON Welcome to TESTING USSD REGISTRATION, ".$userAvailable['name']." Choose a service\n";
                   $response .="1. View details\n";
                   $response .="2. Register\n";
                   $response .="3. Please call me\n";
//        print the response on the page
                   header("Content-type: text/plain");
                   echo $response;

               }

           }
           break;

   }
}
else{
//take the user thru the registration process
//    check that user level is not empty
    if($userRespense==""){

    }

}

?>