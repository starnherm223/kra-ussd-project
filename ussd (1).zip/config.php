<?php
/**
 * Created by PhpStorm.
 * User: CollyneJumah
 * Date: 02/12/2019
 * Time: 12:47
 */

// Specify your login credentials
$username   = "sandbox";
$apikey     = "c541c8114e1b85b6c33f7b4c731959ac878458eb7119700aeb3a76a328c8de5b";

?>