<?php
/**
 * Created by PhpStorm.
 * User: CollinsJumah
 * Date: 4/13/2019
 * Time: 18:57
 */
require '../vendor/autoload.php';
use AfricasTalking\SDK\AfricasTalking;

//connections required
// require_once ('AfricasTalkingGateway.php');
require_once ('config.php');
require_once ('connection.php');

//receive the POSTs from AfricaStalking
$sessionId=$_POST['sessionId'];
$serviceCode=$_POST['serviceCode'];
$phoneNumber=$_POST['phoneNumber'];
$text=$_POST['text'];

//explored text to get valu of the latest interaction using textExplored function
$textArray=explode('*', $text);
$userResponse=trim(end($textArray));

//Set user level to zero(default level of user)
$level=0;

//check the level of user from the db and retain to zero if none is found
$sqlLv = "select level from session_levels where session_id ='".$sessionId." '";
$levelQuery = $conn->query($sqlLv);
if($resultLv = $levelQuery->fetch_assoc()) {
    $level = $resultLv['level'];
}

//=======================check if user/subscriber is in the database====================================================

$sqlCheckUser="SELECT * FROM members WHERE phoneNumber LIKE '%".$phoneNumber."%' LIMIT 1";
//$resultsCheckUser=mysqli_query($conn,$sqlCheckUser);
//$userAvailability=mysqli_fetch_assoc($resultsCheckUser);
$userQuery=$conn->query($sqlCheckUser);
$userAvailability=$userQuery->fetch_assoc();


//if the user(parent) is available, serve the menu,, else prompt for registration

if($userAvailability && $userAvailability['name'] !=NULL && $userAvailability['krapin'] !=NULL && $userAvailability['phoneNumber']){
//    set level to zero
    if($level==0 || $level==1){
        switch ($userResponse){
            case "":
                if($level==0){
                    //             update user level and set to 1 and display the menu
                    $sqluserLvl="INSERT INTO `session_levels`(`session_id`,`phoneNumber`,`level`) VALUES('".$sessionId."','".$phoneNumber."',1)";
                    $resultsUserLvl=mysqli_query($conn,$sqluserLvl);
                    //   serve/ display the menu
                    $response = "CON Welcome to KRA-USSD  " . $userAvailability['name'] . ". Choose a service.\n";
                    $response .= " 1. Enquiry.\n";
                    $response .= " 2. Domestic Tax Service\n";
                    $response .= " 3. Custom Services\n";
                    $response .= " 4. Subscription\n";
                    $response .= " 5. Exit";

                    header('Content-type: text/plain');
                    echo $response;
                }
                break;

            case "0":
                if($level==0){
//                    update user to the next level
                    $sqluserLvl1="INSERT INTO `session_levels`(`session_id`,`phoneNumber`,`level`) VALUES('".$sessionId."','".$phoneNumber."',1)";
                    $resultsUserLvl1=mysqli_query($conn,$sqluserLvl1);
                    //   serve/ display the menu
                    $response = "CON Welcome to KRA-USSD  " . $userAvailability['name'] . ". Choose a service.\n";
                    $response .= " 1. Enquiry.\n";
                    $response .= " 2. Domestic Tax Service\n";
                    $response .= " 3. Return status\n";
                    $response .= " 4. Subscription\n";

                    header('Content-type: text/plain');
                    echo $response;
                }
                break;

            case "1":
                if($level==1){
                    // Check if user is registered
                    $sqlReg="SELECT * FROM members WHERE phoneNumber LIKE '%".$phoneNumber."%' LIMIT 1 ";
                    $resultsReg=mysqli_query($conn,$sqlReg);
                    $checkReg=mysqli_num_rows($resultsReg);
                    if($checkReg >0){
                        $response = "CON You're already registered.\nPress 0 to main menu.";

                        $sqlLevelDemote = "UPDATE `session_levels` SET `level`=0 where `session_id`='" . $sessionId . "'";
                        $conn->query($sqlLevelDemote);

                    }
                    else{
                        $response = "END Your data request not matching or does not exist\n";
                    }

                    // Print the response onto the page so that our gateway can read it
                    header('Content-type: text/plain');
                    echo $response;
                }
                break;

            case "2":
                if($level==1){
//                    select students data from database and print out
                    $response = "END USER INFORMATION:\n";
                    $sql3 = "SELECT * FROM members WHERE phoneNumber='$phoneNumber'";
                    $result3 = mysqli_query($conn, $sql3);
                    $checkData=mysqli_num_rows($result3);

                    while ($row3 = mysqli_fetch_array($result3)) {
                        $idNo3=$row3['krapin'];
                        $name3 = $row3['name'];
                        $date = $row3['created_on'];
                        $status = $row3['status'];

                        if($status == '0')
                        {
                            $status = "Pending file returns";
                        }else
                        {
                            $status = "Filed";
                        }

                    }
                    if($checkData==0){
                        $response = "END User information for provided phone number does not exist.\n";
                    }if ($checkData==1) {
                        //display user tax information
                        $response .= "INFORMATION DETAILS FOR USER PIN : ".$idNo3." \n";
                        $response .= "Name: " . $name3 . "\n";
                        $response .= "Phone: " .$phoneNumber."\n";
                        $response .= "KRA PIN: " . $idNo3 . "\n";
                        $response .= "Status: " . $status . "\n";
                        $response .= "(Choose option 3 to file your nil return before deadline)";
                    }
                    // Print the response onto the page so that our gateway can read it
                    header('Content-type: text/plain');
                    echo $response;
                }
                break;

            case "3":
                if($level==1){
//                    ask user to view return status ,, wanting to view results
                    $response = "CON  SELECT TAX TYPE SERVICE?\n";
                    $response .= "1. Domestic Tax Service\n";
                    $response .= "2. Custom Service\n";

//                    update session to another level
                    $sqlLvl3="UPDATE `session_levels` SET `level`=8 where `session_id`='".$sessionId."'";
                    $conn->query($sqlLvl3);
                    // Print the response onto the page so that our gateway can read it
                    header('Content-type: text/plain');
                    echo $response;
                }
                break;
//=============================================subscription option======================================================
            case "4":
                if($level==1){
                    $response = "CON You are about to subscribe to the following services\n";
                    $response .= " kRA filling reminders \n Notification\nKra Updates\n";
                    $response .= "Are you sure that you want to proceed\n";
                    $response .= "1. YES\n";
                    $response .= "2. NO\n";

                   

                    $username = 'YOUR_USERNAME'; // use 'sandbox' for development in the test environment
                    $apiKey   = 'YOUR_API_KEY'; // use your sandbox app API key for development in the test environment
                    $AT       = new AfricasTalking($username, $apiKey);

                    // Get one of the services
                    $sms      = $AT->sms();

                    // Use the service
                    $result   = $sms->send([
                    'to'      => '$phoneNumber',
                    'message' => 'Hello World!'
                    ]);

                    print_r($result);

//                    update session level to 9 coz user is continuing to enter
                    $sqlLvl10="UPDATE `session_levels` SET `level`=9 where `session_id`='".$sessionId."'";
                    $conn->query($sqlLvl10);

                   
                }
                break;

            case "5":
                if($level==1){
                    $response = "END Thank you for registering with KRA-USSD SERVICE.\n";

                    // Print the response onto the page so that ussd gateway can read it
                    header('Content-type: text/plain');
                    echo $response;
                }
                break;

            default:
                if($level==1){
                    // Return user to Main Menu & Demote user's level
                    $response = "CON You have to choose a service.\n";
                    $response .= "Press 0 to go back.\n";
                    //demote
                    $sqlLevelDemote = "UPDATE `session_levels` SET `level`=0 where `session_id`='" . $sessionId . "'";
                    $conn->query($sqlLevelDemote);

                    // Print the response onto the page so that our gateway can read it
                    header('Content-type: text/plain');
                    echo $response;
                }
        }

    }
    else{
        switch ($level){
            case 8:
                switch ($userResponse){
                    case "1":
                        // ======================Select cancer type and treatment and display the output
                        $sql11b = "UPDATE members SET `status`='".$userResponse."' WHERE `phoneNumber` LIKE '%". $phoneNumber ."%'";
                        $conn->query($sql11b);


                        //display student information
                        $response = "END Dear ".$userAvailability['name']. " Thank you for filling your Nil Return: \n";

                        // Print the response onto the page so that ussd gateway can read it
                        header('Content-type: text/plain');
                        echo $response;
                        break;

                    case "2":
//                     =============jfjf================================

                        $response = "END The custom information service is not available for you: \n";

                        header('Content-type: text/plain');
                        echo $response;
                        break;


// =====================================================================================================================
                    case 9:
                        switch ($userResponse){
                            case "1":
                                $response="END Thank you for subscribing for CANCER USSD SERVICES.";

                                header('Content-type: text/plain');
                                echo $response;
                                break;

                            case "2":
                                $response="END You just cancelled Our services. No worry We will still update you.";

                                header('Content-type: text/plain');
                                echo $response;
                                break;

                            default:
                                $response = "END Apologies, something went wrong. \n";
                                // Print the response onto the page so that ussd gateway can read it
                                header('Content-type: text/plain');
                                echo $response;
                                break;
                        }
                }
        }
    }


}else{
//    register user
//    check user response is not empty
    if($userResponse==""){
        switch ($level){
            case 0:
                //            update user to the next level so you dont serve them the same menu
                $sql10b = "INSERT INTO `session_levels`(`session_id`, `phoneNumber`,`level`) VALUES('".$sessionId."','".$phoneNumber."', 1)";
                $conn->query($sql10b);

                //Insert the phoneNumber, since it comes with the first POST
                $sql10c = "INSERT INTO members(`phoneNumber`) VALUES ('".$phoneNumber."')";
                $conn->query($sql10c);

                //Serve the menu request for name
                $response = "CON Please enter your Name";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;

            case 1:
                // Request again for name - level has not changed...
                $response = "CON Name not supposed to be empty. Please enter your name \n";

                // Print the response onto the page so that gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;

            case 2:
                //10f. Request for city again --- level has not changed...
                $response = "CON KRA pin not supposed to be empty. Please reply with Your PIN number\n";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;

            default:
                //10g. End the session
                $response = "END Apologies, something went wrong. \n";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;

        }
    }else{
//        if not empty, update user details
        switch ($level) {
            case 0:
                //Graduate the user to the next level, so you dont serve them the same menu
                $sqlb = "INSERT INTO `session_levels`(`session_id`, `phoneNumber`,`level`) VALUES('".$sessionId."','".$phoneNumber."', 1)";
                $conn->query($sqlb);

                // Insert the phoneNumber, since it comes with the first POST
                $sqlc = "INSERT INTO members (`phoneNumber`) VALUES ('".$phoneNumber."')";
                $conn->query($sqlc);

                //10d. Serve the menu request for name
                $response = "CON Please enter your full name";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;
            case 1:
                //Update Name, Request for pin
                $sql11b = "UPDATE members SET `name`='".$userResponse."' WHERE `phoneNumber` LIKE '%". $phoneNumber ."%'";
                $conn->query($sql11b);

                //graduate the user to the filling level
                $sql11c = "UPDATE `session_levels` SET `level`=2 WHERE `session_id`='".$sessionId."'";
                $conn->query($sql11c);

                //request for the admission
                $response = "CON Please enter your KRA Pin";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;
            case 2:
                //11d. Update city
                $sql11d = "UPDATE members SET `krapin`='".$userResponse."' WHERE `phoneNumber` = '". $phoneNumber ."'";
                $conn->query($sql11d);

                //11e. Change level to 0
                $sql11e = "INSERT INTO `session_levels`(`session_id`,`phoneNumber`,`level`) VALUES('".$sessionId."','".$phoneNumber."',1)";
                $conn->query($sql11e);

                //11f. Serve the menu request for name
                $response = "END You have been successfully registered to KRA-USSD SERVICE. Dial *384*11222# to choose a service.";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;
            default:
                //11g. Request for city again
                $response = "END Apologies, something went wrong... \n";

                // Print the response onto the page so that our gateway can read it
                header('Content-type: text/plain');
                echo $response;
                break;
        }
    }

}
?>
