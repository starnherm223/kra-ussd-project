<?php
//Connection Credentials
// $servername = 'localhost';
// $username = 'ksucacok_kraussd';
// $password = "kraUSSD@ksuca";
// $database = "ksucacok_kra";
// $dbport = 3306;

$servername = 'localhost';
$username = 'ksucacok_ussd';
$password = "ksucacok_ussd";
$database = "ksucacok_ussd";
$dbport = 3306;

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $dbport);

// Check connection
if ($conn->connect_error) {
    header('Content-type: text/plain');
    //log error to file/db $e-getMessage()
    echo 'END An error was encountered. Please try again later'.mysqli_error($conn);
    // die("");
}
?>
